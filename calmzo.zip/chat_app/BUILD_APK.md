# Build the APK

This project did not include the generated Android platform directory. The included GitHub Actions workflow creates it and builds a release APK automatically.

## Before building

1. Replace the placeholder Firebase configuration in `lib/firebase_options.dart` with the real FlutterFire configuration, or run `flutterfire configure` locally.
2. For Google Sign-In, add your Android app to Firebase and configure the required SHA-1/SHA-256 fingerprints.

## GitHub build

1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build Android APK**.
4. Click **Run workflow** (or push to `main`).
5. Download the `chat-app-release-apk` artifact.
6. Extract it and install `app-release.apk` on Android.

The APK is for direct installation and does not require Google Play Store publication.
