import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/auth_service.dart';
import '../services/notification_service.dart';
import '../services/presence_service.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());

final notificationServiceProvider =
    Provider<NotificationService>((ref) => NotificationService());

final presenceServiceProvider =
    Provider<PresenceService>((ref) => PresenceService());

/// Emits the current FirebaseAuth user, or null when signed out.
final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authServiceProvider).authStateChanges;
});

/// Convenience accessor for the current uid, or null.
final currentUidProvider = Provider<String?>((ref) {
  return ref.watch(authStateProvider).value?.uid;
});
