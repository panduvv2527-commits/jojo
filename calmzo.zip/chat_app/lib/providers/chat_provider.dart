import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/chat.dart';
import '../models/message.dart';
import '../models/user.dart';
import '../services/chat_service.dart';
import 'auth_provider.dart';

final chatServiceProvider = Provider<ChatService>((ref) {
  final service = ChatService();
  ref.onDispose(service.disposeTyping);
  return service;
});

/// Streams the current user's chat list, sorted by updatedAt descending.
final chatListProvider = StreamProvider<List<Chat>>((ref) {
  final uid = ref.watch(currentUidProvider);
  if (uid == null) return const Stream.empty();
  return ref.watch(chatServiceProvider).streamChats(uid);
});

/// Streams a single chat doc, e.g. for the typing indicator in ChatScreen.
final chatDocProvider = StreamProvider.family<Chat?, String>((ref, chatId) {
  return ref.watch(chatServiceProvider).streamChat(chatId);
});

/// Streams the most recent page of messages for a chat.
final messagesProvider =
    StreamProvider.family<List<Message>, String>((ref, chatId) {
  return ref.watch(chatServiceProvider).streamMessages(chatId);
});

/// Looks up a user profile by uid, for rendering chat tiles / headers.
final userProfileProvider =
    StreamProvider.family<AppUser?, String>((ref, uid) {
  if (uid.isEmpty) return const Stream.empty();
  return FirebaseFirestore.instance
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((doc) => doc.exists ? AppUser.fromDoc(doc) : null);
});
