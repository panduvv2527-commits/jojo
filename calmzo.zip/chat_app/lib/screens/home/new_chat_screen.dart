import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../services/chat_service.dart';

/// Simple user search to start a new 1:1 chat. Searches users by exact
/// email match, since Firestore doesn't support partial-text queries
/// out of the box.
class NewChatScreen extends ConsumerStatefulWidget {
  const NewChatScreen({super.key});

  @override
  ConsumerState<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends ConsumerState<NewChatScreen> {
  final _controller = TextEditingController();
  bool _isSearching = false;
  bool _isStarting = false;
  String? _error;
  AppUser? _result;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final email = _controller.text.trim();
    if (email.isEmpty) return;
    setState(() {
      _isSearching = true;
      _error = null;
      _result = null;
    });
    try {
      final snap = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();
      if (snap.docs.isEmpty) {
        setState(() => _error = 'No user found with that email.');
      } else {
        setState(() => _result = AppUser.fromDoc(snap.docs.first));
      }
    } catch (e) {
      setState(() => _error = 'Search failed: $e');
    } finally {
      if (mounted) setState(() => _isSearching = false);
    }
  }

  Future<void> _startChat(AppUser other) async {
    final uid = ref.read(currentUidProvider);
    if (uid == null) return;
    if (other.uid == uid) {
      setState(() => _error = "You can't start a chat with yourself.");
      return;
    }
    setState(() => _isStarting = true);
    try {
      final chatId =
          await ref.read(chatServiceProvider).getOrCreateChat(uid, other.uid);
      if (mounted) context.pushReplacement('/chat/$chatId');
    } on ChatException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _isStarting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New chat')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Find by email',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _isSearching ? null : _search,
                  icon: _isSearching
                      ? const SizedBox(
                          height: 18,
                          width: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.search),
                ),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            if (_result != null) ...[
              const SizedBox(height: 16),
              Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: _result!.photoUrl.isNotEmpty
                        ? NetworkImage(_result!.photoUrl)
                        : null,
                    child: _result!.photoUrl.isEmpty
                        ? Text(_result!.displayName.isNotEmpty
                            ? _result!.displayName[0].toUpperCase()
                            : '?')
                        : null,
                  ),
                  title: Text(_result!.displayName),
                  subtitle: Text(_result!.email),
                  trailing: _isStarting
                      ? const SizedBox(
                          height: 18,
                          width: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.chevron_right),
                  onTap: _isStarting ? null : () => _startChat(_result!),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
