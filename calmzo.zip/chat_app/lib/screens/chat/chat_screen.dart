import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../models/message.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../services/chat_service.dart';
import '../../widgets/message_bubble.dart';
import '../../widgets/typing_indicator.dart';

/// The 1:1 conversation screen.
///
/// StatefulWidget (not Stateless) because it owns a [TextEditingController]
/// and a [ScrollController] that must be created once in [initState] and
/// disposed in [dispose] — creating them in build() leaks a new controller
/// on every rebuild.
class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key, required this.chatId});

  final String chatId;

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  late final TextEditingController _textController;
  late final ScrollController _scrollController;
  final ImagePicker _imagePicker = ImagePicker();

  bool _isSending = false;
  bool _isLoadingMore = false;
  bool _hasMore = true;
  List<Message> _olderMessages = [];
  DocumentSnapshot<Map<String, dynamic>>? _oldestCursor;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController();
    _scrollController = ScrollController()..addListener(_onScroll);

    // Mark existing messages read as soon as the screen opens.
    WidgetsBinding.instance.addPostFrameCallback((_) => _markRead());
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController
      ..removeListener(_onScroll)
      ..dispose();
    final uid = ref.read(currentUidProvider);
    if (uid != null) {
      ref.read(chatServiceProvider).setTyping(widget.chatId, uid, false);
    }
    super.dispose();
  }

  void _onScroll() {
    // ListView is reversed, so "scrolled to top of history" means the
    // scroll offset is near the max extent.
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _loadMore();
    }
  }

  Future<void> _markRead() async {
    final uid = ref.read(currentUidProvider);
    if (uid == null) return;
    try {
      await ref.read(chatServiceProvider).markAsRead(widget.chatId, uid);
    } on ChatException {
      // Non-fatal: read receipts are best-effort from the UI's perspective.
    }
  }

  Future<void> _loadMore() async {
    if (_isLoadingMore || !_hasMore || _oldestCursor == null) return;
    setState(() => _isLoadingMore = true);
    try {
      final more = await ref.read(chatServiceProvider).loadMoreMessages(
            widget.chatId,
            startAfter: _oldestCursor!,
          );
      setState(() {
        _hasMore = more.length == ChatService.defaultPageSize;
        _olderMessages = [..._olderMessages, ...more];
      });
    } on ChatException catch (e) {
      _showError(e.message);
    } finally {
      if (mounted) setState(() => _isLoadingMore = false);
    }
  }

  /// Shared send logic used by both the send button and onSubmitted, so
  /// there's exactly one path that writes a message.
  Future<void> _send({String? mediaUrl, MessageType? mediaType}) async {
    final uid = ref.read(currentUidProvider);
    if (uid == null) return;

    final text = _textController.text;
    if (mediaUrl == null && text.trim().isEmpty) return;

    final chat = ref.read(chatDocProvider(widget.chatId)).value;
    final recipientId = chat?.otherUserId(uid) ?? '';

    setState(() => _isSending = true);
    _textController.clear();
    ref.read(chatServiceProvider).setTyping(widget.chatId, uid, false);

    try {
      if (mediaUrl != null && mediaType != null) {
        await ref.read(chatServiceProvider).sendMediaMessage(
              chatId: widget.chatId,
              senderId: uid,
              recipientId: recipientId,
              mediaUrl: mediaUrl,
              type: mediaType,
              caption: text.trim(),
            );
      } else {
        await ref.read(chatServiceProvider).sendTextMessage(
              chatId: widget.chatId,
              senderId: uid,
              recipientId: recipientId,
              text: text,
            );
      }
      _scrollToBottom();
    } on ChatException catch (e) {
      _showError(e.message);
      // Restore the text so the user doesn't lose what they typed.
      _textController.text = text;
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _pickAndSendImage() async {
    final uid = ref.read(currentUidProvider);
    if (uid == null) return;
    try {
      final picked = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );
      if (picked == null) return;

      final storageRef = FirebaseStorage.instance.ref().child(
          'chat_images/${widget.chatId}/${DateTime.now().millisecondsSinceEpoch}.jpg');
      await storageRef.putFile(File(picked.path));
      final url = await storageRef.getDownloadURL();
      await _send(mediaUrl: url, mediaType: MessageType.image);
    } catch (e) {
      _showError('Failed to send image: $e');
    }
  }

  void _onTextChanged(String value) {
    final uid = ref.read(currentUidProvider);
    if (uid == null) return;
    ref.read(chatServiceProvider).setTyping(
          widget.chatId,
          uid,
          value.trim().isNotEmpty,
        );
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final uid = ref.watch(currentUidProvider);
    final messagesAsync = ref.watch(messagesProvider(widget.chatId));
    final chatAsync = ref.watch(chatDocProvider(widget.chatId));

    return Scaffold(
      appBar: AppBar(
        title: chatAsync.when(
          data: (chat) {
            final otherUid =
                uid != null && chat != null ? chat.otherUserId(uid) : '';
            final otherUserAsync = ref.watch(userProfileProvider(otherUid));
            final name = otherUserAsync.value?.displayName ?? '...';
            final isTyping = chat?.isOtherTyping(otherUid) ?? false;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(name),
                TypingIndicator(isTyping: isTyping, name: name),
              ],
            );
          },
          loading: () => const Text('...'),
          error: (_, __) => const Text('Chat'),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: messagesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Could not load messages.'),
                    const SizedBox(height: 8),
                    FilledButton(
                      onPressed: () => ref.invalidate(messagesProvider(widget.chatId)),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
              data: (liveMessages) {
                if (liveMessages.isNotEmpty) {
                  _oldestCursor ??= null; // set below once doc is fetched
                  _fetchCursorIfNeeded(liveMessages.last);
                }
                final allMessages = [...liveMessages, ..._olderMessages];

                if (allMessages.isEmpty) {
                  return Center(
                    child: Text(
                      'No messages yet.\nSay hello 👋',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  );
                }

                return ListView.builder(
                  controller: _scrollController,
                  reverse: true,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: allMessages.length + (_isLoadingMore ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == allMessages.length) {
                      return const Padding(
                        padding: EdgeInsets.all(12),
                        child: Center(
                          child: SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        ),
                      );
                    }
                    final message = allMessages[index];
                    return MessageBubble(
                      message: message,
                      isMine: uid != null && message.isMine(uid),
                    );
                  },
                );
              },
            ),
          ),
          _MessageInput(
            controller: _textController,
            isSending: _isSending,
            onChanged: _onTextChanged,
            onSend: () => _send(),
            onAttach: _pickAndSendImage,
          ),
        ],
      ),
    );
  }

  void _fetchCursorIfNeeded(Message lastLiveMessage) async {
    if (_oldestCursor != null) return;
    final doc = await ref
        .read(chatServiceProvider)
        .messageDoc(widget.chatId, lastLiveMessage.id);
    if (doc != null && mounted) {
      _oldestCursor = doc;
    }
  }
}

class _MessageInput extends StatelessWidget {
  const _MessageInput({
    required this.controller,
    required this.isSending,
    required this.onChanged,
    required this.onSend,
    required this.onAttach,
  });

  final TextEditingController controller;
  final bool isSending;
  final ValueChanged<String> onChanged;
  final VoidCallback onSend;
  final VoidCallback onAttach;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.image_outlined),
              onPressed: isSending ? null : onAttach,
            ),
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 4,
                textInputAction: TextInputAction.send,
                onChanged: onChanged,
                onSubmitted: (_) => onSend(),
                decoration: const InputDecoration(
                  hintText: 'Message',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(24)),
                  ),
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 4),
            ValueListenableBuilder<TextEditingValue>(
              valueListenable: controller,
              builder: (context, value, _) {
                final canSend = value.text.trim().isNotEmpty && !isSending;
                return IconButton(
                  icon: isSending
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.send),
                  onPressed: canSend ? onSend : null,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

