import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/chat.dart';
import '../models/message.dart';

class ChatException implements Exception {
  final String message;
  const ChatException(this.message);
  @override
  String toString() => message;
}

/// Wraps all Firestore reads/writes for chats and messages.
///
/// Chat IDs are deterministic — `Chat.idFor(uidA, uidB)` — so opening or
/// creating a 1:1 chat is always a single doc read/write instead of an
/// O(n) query over the chats collection.
class ChatService {
  ChatService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  static const int defaultPageSize = 30;
  final Map<String, Timer> _typingTimers = {};

  CollectionReference<Map<String, dynamic>> get _chats =>
      _firestore.collection('chats');

  CollectionReference<Map<String, dynamic>> _messages(String chatId) =>
      _chats.doc(chatId).collection('messages');

  /// Streams all chats the given user is a member of, newest first.
  Stream<List<Chat>> streamChats(String uid) {
    return _chats
        .where('members', arrayContains: uid)
        .orderBy('updatedAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(Chat.fromDoc).toList())
        .handleError((error) {
      throw ChatException('Failed to load chats: $error');
    });
  }

  /// Streams a single chat doc (used for AppBar title / typing indicator).
  Stream<Chat?> streamChat(String chatId) {
    return _chats.doc(chatId).snapshots().map(
          (doc) => doc.exists ? Chat.fromDoc(doc) : null,
        );
  }

  /// Gets an existing 1:1 chat between two users or creates it.
  /// Uses a deterministic ID so this is always a single doc read,
  /// with a create-on-miss write guarded by a transaction.
  Future<String> getOrCreateChat(String uidA, String uidB) async {
    final chatId = Chat.idFor(uidA, uidB);
    final docRef = _chats.doc(chatId);
    try {
      await _firestore.runTransaction((tx) async {
        final snap = await tx.get(docRef);
        if (!snap.exists) {
          tx.set(docRef, {
            'members': [uidA, uidB],
            'lastMessage': '',
            'lastSenderId': '',
            'updatedAt': FieldValue.serverTimestamp(),
            'typing': {uidA: false, uidB: false},
            'unreadCount': {uidA: 0, uidB: 0},
          });
        }
      });
      return chatId;
    } catch (e) {
      throw ChatException('Failed to open chat: $e');
    }
  }

  /// Streams the most recent [limit] messages, newest first (for use with
  /// `ListView(reverse: true)`).
  Stream<List<Message>> streamMessages(String chatId, {int limit = defaultPageSize}) {
    return _messages(chatId)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) => snap.docs.map(Message.fromDoc).toList())
        .handleError((error) {
      throw ChatException('Failed to load messages: $error');
    });
  }

  /// Loads a page of older messages, starting after [startAfter].
  /// Used for pagination when the user scrolls toward the top of history.
  Future<List<Message>> loadMoreMessages(
    String chatId, {
    required DocumentSnapshot<Map<String, dynamic>> startAfter,
    int limit = defaultPageSize,
  }) async {
    try {
      final snap = await _messages(chatId)
          .orderBy('createdAt', descending: true)
          .startAfterDocument(startAfter)
          .limit(limit)
          .get();
      return snap.docs.map(Message.fromDoc).toList();
    } catch (e) {
      throw ChatException('Failed to load older messages: $e');
    }
  }

  /// Raw doc fetch, used to get the DocumentSnapshot cursor for pagination
  /// when only the typed Message is available on screen.
  Future<DocumentSnapshot<Map<String, dynamic>>?> messageDoc(
    String chatId,
    String messageId,
  ) async {
    final doc = await _messages(chatId).doc(messageId).get();
    return doc.exists ? doc : null;
  }

  /// Sends a text message and updates the parent chat's preview fields.
  Future<void> sendTextMessage({
    required String chatId,
    required String senderId,
    required String recipientId,
    required String text,
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    try {
      final batch = _firestore.batch();
      final msgRef = _messages(chatId).doc();
      batch.set(msgRef, {
        'senderId': senderId,
        'text': trimmed,
        'type': 'text',
        'mediaUrl': null,
        'createdAt': FieldValue.serverTimestamp(),
        'status': 'sent',
        'readBy': <String>[],
      });
      batch.update(_chats.doc(chatId), {
        'lastMessage': trimmed,
        'lastSenderId': senderId,
        'updatedAt': FieldValue.serverTimestamp(),
        'typing.$senderId': false,
        'unreadCount.$recipientId': FieldValue.increment(1),
      });
      await batch.commit();
    } catch (e) {
      throw ChatException('Failed to send message: $e');
    }
  }

  /// Sends an image/file message once the media has already been uploaded
  /// to Storage and [mediaUrl] is known.
  Future<void> sendMediaMessage({
    required String chatId,
    required String senderId,
    required String recipientId,
    required String mediaUrl,
    required MessageType type,
    String caption = '',
  }) async {
    try {
      final batch = _firestore.batch();
      final msgRef = _messages(chatId).doc();
      batch.set(msgRef, {
        'senderId': senderId,
        'text': caption,
        'type': type.name,
        'mediaUrl': mediaUrl,
        'createdAt': FieldValue.serverTimestamp(),
        'status': 'sent',
        'readBy': <String>[],
      });
      final preview = type == MessageType.image ? '📷 Photo' : '📎 File';
      batch.update(_chats.doc(chatId), {
        'lastMessage': caption.isNotEmpty ? caption : preview,
        'lastSenderId': senderId,
        'updatedAt': FieldValue.serverTimestamp(),
        'unreadCount.$recipientId': FieldValue.increment(1),
      });
      await batch.commit();
    } catch (e) {
      throw ChatException('Failed to send attachment: $e');
    }
  }

  /// Writes `chats/{chatId}.typing.{uid}`, debounced so rapid keystrokes
  /// don't spam Firestore writes. Automatically clears the flag after
  /// [idleDuration] of no further calls.
  void setTyping(
    String chatId,
    String uid,
    bool isTyping, {
    Duration idleDuration = const Duration(seconds: 2),
  }) {
    final key = '$chatId:$uid';
    _typingTimers[key]?.cancel();

    _chats.doc(chatId).update({'typing.$uid': isTyping}).catchError((_) {
      // Best-effort; typing indicator failures shouldn't break the UI.
    });

    if (isTyping) {
      _typingTimers[key] = Timer(idleDuration, () {
        _chats.doc(chatId).update({'typing.$uid': false}).catchError((_) {});
      });
    }
  }

  /// Batch-marks all messages not sent by [uid] as read, and clears
  /// [uid]'s unread counter on the parent chat.
  Future<void> markAsRead(String chatId, String uid) async {
    try {
      final unreadSnap = await _messages(chatId)
          .where('senderId', isNotEqualTo: uid)
          .get();

      final toUpdate = unreadSnap.docs.where((doc) {
        final readBy = List<String>.from(doc.data()['readBy'] as List? ?? const []);
        final status = doc.data()['status'] as String?;
        return !readBy.contains(uid) || status != 'read';
      });

      if (toUpdate.isEmpty) {
        await _chats.doc(chatId).update({'unreadCount.$uid': 0});
        return;
      }

      final batch = _firestore.batch();
      for (final doc in toUpdate) {
        batch.update(doc.reference, {
          'status': 'read',
          'readBy': FieldValue.arrayUnion([uid]),
        });
      }
      batch.update(_chats.doc(chatId), {'unreadCount.$uid': 0});
      await batch.commit();
    } catch (e) {
      throw ChatException('Failed to mark messages as read: $e');
    }
  }

  void disposeTyping() {
    for (final timer in _typingTimers.values) {
      timer.cancel();
    }
    _typingTimers.clear();
  }
}
