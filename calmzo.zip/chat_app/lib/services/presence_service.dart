import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

/// Updates users/{uid}.lastSeen whenever the app is foregrounded,
/// backgrounded, or closed. Attach via [attach] from a top-level widget
/// that outlives navigation (e.g. wrapping the app's home).
class PresenceService with WidgetsBindingObserver {
  PresenceService({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;
  String? _uid;

  void attach(String uid) {
    _uid = uid;
    WidgetsBinding.instance.addObserver(this);
    _touch();
  }

  void detach() {
    WidgetsBinding.instance.removeObserver(this);
    _uid = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _touch();
    }
  }

  Future<void> _touch() async {
    final uid = _uid;
    if (uid == null) return;
    try {
      await _firestore.collection('users').doc(uid).update({
        'lastSeen': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('PresenceService failed to update lastSeen: $e');
    }
  }
}
