import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'firebase_options.dart';
import 'providers/auth_provider.dart';
import 'router.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ProviderScope(child: ChatApp()));
}

class ChatApp extends ConsumerStatefulWidget {
  const ChatApp({super.key});

  @override
  ConsumerState<ChatApp> createState() => _ChatAppState();
}

class _ChatAppState extends ConsumerState<ChatApp> {
  String? _presenceUid;

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(routerProvider);

    // Wire up presence + notifications whenever the signed-in user changes.
    ref.listen(currentUidProvider, (previous, next) {
      final presence = ref.read(presenceServiceProvider);
      if (next != null && next != _presenceUid) {
        _presenceUid = next;
        presence.attach(next);
        ref.read(notificationServiceProvider).initialize(next);
      } else if (next == null && _presenceUid != null) {
        presence.detach();
        _presenceUid = null;
      }
    });

    return MaterialApp.router(
      title: 'Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      routerConfig: router,
    );
  }
}
