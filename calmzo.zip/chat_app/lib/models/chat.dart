import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a 1:1 chat document at chats/{chatId}.
class Chat {
  final String id;
  final List<String> members;
  final String lastMessage;
  final String lastSenderId;
  final DateTime? updatedAt;
  final Map<String, bool> typing;
  final Map<String, int> unreadCount;

  const Chat({
    required this.id,
    required this.members,
    required this.lastMessage,
    required this.lastSenderId,
    required this.updatedAt,
    required this.typing,
    required this.unreadCount,
  });

  factory Chat.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return Chat(
      id: doc.id,
      members: List<String>.from(data['members'] as List? ?? const []),
      lastMessage: (data['lastMessage'] as String?) ?? '',
      lastSenderId: (data['lastSenderId'] as String?) ?? '',
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      typing: Map<String, bool>.from(data['typing'] as Map? ?? const {}),
      unreadCount:
          Map<String, int>.from(data['unreadCount'] as Map? ?? const {}),
    );
  }

  /// Returns the uid of the other participant in this 1:1 chat.
  String otherUserId(String currentUid) {
    return members.firstWhere(
      (id) => id != currentUid,
      orElse: () => '',
    );
  }

  bool isOtherTyping(String otherUid) => typing[otherUid] ?? false;

  int unreadFor(String uid) => unreadCount[uid] ?? 0;

  /// Deterministic chat ID for a pair of users, independent of order.
  static String idFor(String uidA, String uidB) {
    final sorted = [uidA, uidB]..sort();
    return sorted.join('_');
  }
}
