import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a user profile stored at users/{uid}.
class AppUser {
  final String uid;
  final String displayName;
  final String photoUrl;
  final String email;
  final String? fcmToken;
  final DateTime? lastSeen;

  const AppUser({
    required this.uid,
    required this.displayName,
    required this.photoUrl,
    required this.email,
    this.fcmToken,
    this.lastSeen,
  });

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return AppUser(
      uid: doc.id,
      displayName: (data['displayName'] as String?) ?? '',
      photoUrl: (data['photoUrl'] as String?) ?? '',
      email: (data['email'] as String?) ?? '',
      fcmToken: data['fcmToken'] as String?,
      lastSeen: (data['lastSeen'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'displayName': displayName,
      'photoUrl': photoUrl,
      'email': email,
      if (fcmToken != null) 'fcmToken': fcmToken,
    };
  }

  AppUser copyWith({
    String? displayName,
    String? photoUrl,
    String? fcmToken,
    DateTime? lastSeen,
  }) {
    return AppUser(
      uid: uid,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      email: email,
      fcmToken: fcmToken ?? this.fcmToken,
      lastSeen: lastSeen ?? this.lastSeen,
    );
  }
}
