import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType { text, image, file }

enum MessageStatus { sent, delivered, read }

MessageType _typeFromString(String? value) {
  switch (value) {
    case 'image':
      return MessageType.image;
    case 'file':
      return MessageType.file;
    case 'text':
    default:
      return MessageType.text;
  }
}

MessageStatus _statusFromString(String? value) {
  switch (value) {
    case 'read':
      return MessageStatus.read;
    case 'delivered':
      return MessageStatus.delivered;
    case 'sent':
    default:
      return MessageStatus.sent;
  }
}

/// Represents a single message at chats/{chatId}/messages/{messageId}.
class Message {
  final String id;
  final String senderId;
  final String text;
  final MessageType type;
  final String? mediaUrl;
  final DateTime? createdAt;
  final MessageStatus status;
  final List<String> readBy;

  const Message({
    required this.id,
    required this.senderId,
    required this.text,
    required this.type,
    this.mediaUrl,
    required this.createdAt,
    required this.status,
    required this.readBy,
  });

  factory Message.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return Message(
      id: doc.id,
      senderId: (data['senderId'] as String?) ?? '',
      text: (data['text'] as String?) ?? '',
      type: _typeFromString(data['type'] as String?),
      mediaUrl: data['mediaUrl'] as String?,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      status: _statusFromString(data['status'] as String?),
      readBy: List<String>.from(data['readBy'] as List? ?? const []),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'senderId': senderId,
      'text': text,
      'type': type.name,
      if (mediaUrl != null) 'mediaUrl': mediaUrl,
      'createdAt': FieldValue.serverTimestamp(),
      'status': status.name,
      'readBy': readBy,
    };
  }

  bool isMine(String uid) => senderId == uid;
}
