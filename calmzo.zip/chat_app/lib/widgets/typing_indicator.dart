import 'package:flutter/material.dart';

/// Shows "<name> is typing…" — intended for use as an AppBar subtitle,
/// driven by a StreamBuilder on the chat doc's `typing` field.
class TypingIndicator extends StatelessWidget {
  const TypingIndicator({
    super.key,
    required this.isTyping,
    required this.name,
  });

  final bool isTyping;
  final String name;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: isTyping
          ? Text(
              'typing…',
              key: const ValueKey('typing'),
              style: TextStyle(
                fontSize: 13,
                fontStyle: FontStyle.italic,
                color: theme.colorScheme.primary,
              ),
            )
          : Text(
              'online',
              key: const ValueKey('online'),
              style: TextStyle(
                fontSize: 13,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
    );
  }
}
