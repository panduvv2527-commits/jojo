# Chat App

A real-time 1:1 messaging app built with Flutter, Cloud Firestore, Firebase Auth,
Firebase Storage, and Firebase Cloud Messaging. State management via Riverpod,
navigation via GoRouter.

## Features

- Email/password + Google sign-in, sign-up, logout, password reset
- Real-time chat list sorted by most recent activity, with unread badges
- Real-time message thread with sent/delivered/read ticks
- Image attachments via Firebase Storage
- Typing indicator (debounced writes)
- Read receipts (batch-marked on chat open)
- Pagination (30 messages per page, loaded on scroll-to-top)
- Presence (`lastSeen`) tracked via app lifecycle
- Push notifications via a Cloud Function on new message
- Loading / error / empty states throughout

## Project structure

```
lib/
├─ main.dart
├─ firebase_options.dart      # placeholder — regenerate with flutterfire configure
├─ router.dart
├─ models/                    # Chat, Message, AppUser — typed, fromDoc factories
├─ services/                  # AuthService, ChatService, NotificationService, PresenceService
├─ providers/                 # Riverpod providers wiring services to streams
├─ screens/
│  ├─ auth/                   # login, signup
│  ├─ home/                   # chat list, new chat
│  └─ chat/                   # the conversation screen
└─ widgets/                   # message_bubble, chat_tile, typing_indicator
functions/
└─ src/index.ts               # onMessageCreate Cloud Function (TypeScript)
firestore.rules
firestore.indexes.json
```

## Setup

### 1. Prerequisites

- Flutter (latest stable) with Dart 3
- A Firebase project (create one at https://console.firebase.google.com)
- Node.js 20+ (for Cloud Functions)
- The Firebase CLI: `npm install -g firebase-tools`
- The FlutterFire CLI: `dart pub global activate flutterfire_cli`

### 2. Install Flutter dependencies

```bash
flutter pub get
```

### 3. Connect the app to your Firebase project

```bash
firebase login
flutterfire configure
```

This regenerates `lib/firebase_options.dart` with your real project's
config and registers the Android/iOS/web apps. **Replace the placeholder
file that ships in this repo** — it will not compile against a real
backend as-is.

### 4. Enable required Firebase products

In the Firebase console for your project:

- **Authentication** → Sign-in method → enable **Email/Password** and **Google**
- **Firestore Database** → create a database (start in production mode; the
  rules below lock it down)
- **Storage** → create a default bucket (for image messages)
- **Cloud Messaging** → no extra setup needed beyond the default; for iOS
  you'll also need an APNs auth key uploaded under Project Settings → Cloud Messaging

### 5. Deploy Firestore rules and indexes

```bash
firebase deploy --only firestore:rules,firestore:indexes
```

`firestore.rules` restricts:
- `users/{uid}` — readable by any signed-in user, writable only by its owner
- `chats/{chatId}` and its `messages` subcollection — readable/writable only
  by the two uids listed in `members`
- Message `create` requires `senderId == request.auth.uid`
- Message `update` is restricted to fields other than `text`/`senderId`
  (used for read-receipt updates only)

### 6. Deploy Cloud Functions

```bash
cd functions
npm install
npm run deploy
```

This deploys `onMessageCreate`, which triggers on
`chats/{chatId}/messages/{messageId}` creation and:
1. Reads the recipient's `fcmToken` from `users/{uid}`
2. Sends an FCM push with the sender's name and message preview
3. Increments `unreadCount.{recipientUid}` on the parent chat
4. Updates `lastMessage`, `lastSenderId`, and `updatedAt`

(The Flutter client already writes these fields optimistically in the same
batch as the message — the function acts as a durable, idempotent backstop.)

### 7. Platform-specific push notification setup

- **Android**: no extra code needed; `google-services.json` from
  `flutterfire configure` is sufficient. Create a notification channel
  matching `chat_messages` (used in the function's `android.notification.channelId`)
  if you want custom sound/importance behavior.
- **iOS**: enable Push Notifications + Background Modes → Remote notifications
  in Xcode, and upload your APNs key to Firebase.

### 8. Run the app

```bash
flutter run
```

## Notes on the data model

- Chat IDs are **deterministic**: `Chat.idFor(uidA, uidB)` sorts and joins
  the two uids, so opening or creating a 1:1 chat is a single `.doc(id).get()`
  instead of an O(n) query over the `chats` collection.
- All timestamps use `FieldValue.serverTimestamp()`.
- `ChatScreen` is a `ConsumerStatefulWidget` so its `TextEditingController`
  and `ScrollController` are created once in `initState` and disposed in
  `dispose` — never recreated on rebuild.
