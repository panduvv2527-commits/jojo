import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { logger } from "firebase-functions/v2";

initializeApp();

const db = getFirestore();
const messaging = getMessaging();

interface ChatData {
  members: string[];
  lastMessage?: string;
  lastSenderId?: string;
  unreadCount?: Record<string, number>;
}

interface MessageData {
  senderId: string;
  text: string;
  type: "text" | "image" | "file";
  mediaUrl?: string | null;
  status: "sent" | "delivered" | "read";
}

/**
 * Fires whenever a new message document is created under
 * chats/{chatId}/messages/{messageId}.
 *
 * Responsibilities:
 *  1. Look up the recipient's fcmToken from users/{uid}
 *  2. Send a push notification with sender name + message preview
 *  3. Increment unreadCount.{recipientUid} on the parent chat
 *  4. Update lastMessage, lastSenderId, and updatedAt on the parent chat
 *
 * Note: the Flutter client's ChatService already writes lastMessage /
 * unreadCount / updatedAt optimistically in the same batch as the message
 * write (see sendTextMessage / sendMediaMessage), so steps 3-4 here act as
 * a durable server-side source of truth in case the client write fails,
 * is offline-queued, or the message is created by another trusted path
 * (e.g. a future admin/back-office tool). Firestore's merge write makes
 * this idempotent alongside the client update.
 */
export const onMessageCreate = onDocumentCreated(
  "chats/{chatId}/messages/{messageId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) {
      logger.warn("onMessageCreate: no snapshot data, skipping.");
      return;
    }

    const { chatId } = event.params as { chatId: string };
    const message = snapshot.data() as MessageData;

    try {
      const chatRef = db.collection("chats").doc(chatId);
      const chatSnap = await chatRef.get();

      if (!chatSnap.exists) {
        logger.warn(`onMessageCreate: chat ${chatId} not found.`);
        return;
      }

      const chat = chatSnap.data() as ChatData;
      const recipientId = chat.members.find((id) => id !== message.senderId);

      if (!recipientId) {
        logger.warn(`onMessageCreate: no recipient found for chat ${chatId}.`);
        return;
      }

      const preview =
        message.type === "image"
          ? "📷 Photo"
          : message.type === "file"
          ? "📎 File"
          : message.text;

      // Update chat preview fields + unread count. This mirrors the
      // client's optimistic write, so it's safe to run even if the
      // client already applied it (last write wins on identical data).
      await chatRef.update({
        lastMessage: preview,
        lastSenderId: message.senderId,
        updatedAt: FieldValue.serverTimestamp(),
        [`unreadCount.${recipientId}`]: FieldValue.increment(1),
      });

      // Fetch recipient + sender profiles for the push payload.
      const [recipientDoc, senderDoc] = await Promise.all([
        db.collection("users").doc(recipientId).get(),
        db.collection("users").doc(message.senderId).get(),
      ]);

      const fcmToken = recipientDoc.data()?.fcmToken as string | undefined;
      if (!fcmToken) {
        logger.info(`onMessageCreate: recipient ${recipientId} has no fcmToken.`);
        return;
      }

      const senderName =
        (senderDoc.data()?.displayName as string | undefined) || "New message";

      await messaging.send({
        token: fcmToken,
        notification: {
          title: senderName,
          body: preview,
        },
        data: {
          chatId,
          senderId: message.senderId,
          type: "chat_message",
        },
        apns: {
          payload: {
            aps: { sound: "default" },
          },
        },
        android: {
          priority: "high",
          notification: { channelId: "chat_messages" },
        },
      });

      logger.info(`onMessageCreate: notified ${recipientId} for chat ${chatId}.`);
    } catch (error) {
      logger.error("onMessageCreate failed:", error);
    }
  }
);
